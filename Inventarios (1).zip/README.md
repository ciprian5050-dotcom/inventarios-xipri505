
  # Inventarios

  This is a code bundle for Inventarios. The original project is available at https://www.figma.com/design/Ye4TDdV2wygiyNd0l07YN8/Inventarios.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  