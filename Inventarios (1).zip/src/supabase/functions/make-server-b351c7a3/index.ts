// Edge Function Entry Point
// This file re-exports the main server from the server directory

// Import the server from the server directory
import '../server/index.tsx';
